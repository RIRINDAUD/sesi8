<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$nama = $_POST['nama'];
$nim = $_POST['nim'];
$alamat = $_POST['alamat'];
$nohp = $_POST['nohp'];
$tgllahir = $_POST['tgllahir'];
 
// menginput data ke database
mysqli_query($koneksi,"insert into mahasiswa values('','$nim','$nama','$nohp','$alamat','$tgllahir')");
 
// mengalihkan halaman kembali ke index.php
header("location:index.php");
 
?>